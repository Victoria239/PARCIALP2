import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;

@Bean
public CommandLineRunner initData(SerieRepository serieRepo, TemporadaRepository temporadaRepo, EpisodioRepository episodioRepo, PersonajesRepository personajesRepo) {
    return args -> {
        // Crear y guardar una serie
        Serie serie = new Serie("Peaky Blinders", "Descripción de la serie", "Creador de la serie", "Clasificación");
        serieRepo.save(serie);

// Crear y guardar temporadas y episodios
        Temporada temporada1 = new Temporada(1, 2013, serie);
        temporadaRepo.save(temporada1);
        Episodio episodio1 = new Episodio("E01", "Nombre del episodio", "Descripción del episodio", temporada1, 4.5);
        episodioRepo.save(episodio1);

// Crear y guardar personajes
        Personajes personaje = new Personajes("Tommy Shelby", "Descripción de Tommy Shelby", "URL de la imagen");
        personajesRepo.save(personaje);
};
}
