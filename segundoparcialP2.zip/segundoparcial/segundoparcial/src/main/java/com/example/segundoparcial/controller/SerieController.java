package com.example.segundoparcial.controller;

import com.example.segundoparcial.model.Serie;
import com.example.segundoparcial.service.SerieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/series")
public class SerieController {

    @Autowired
    private SerieService serieService;

    @GetMapping
    public List<Serie> getSeries() {
        return serieService.getAllSeries();
    }

    @GetMapping("/{id}")
    public Optional<Serie> getSerie(@PathVariable Long id) {
        return serieService.getSerieById(id);
    }

    @PostMapping
    public Serie createSerie(@RequestBody Serie serie) {
        return serieService.createSerie(serie);
    }
}
