package com.example.segundoparcial.repository;
import com.example.segundoparcial.model.Temporada;
import org.springframework.data.jpa.repository.JpaRepository;



    public interface TemporadaRepository extends JpaRepository<Temporada, Long> {
    }
