package com.example.segundoparcial.service;


import com.example.segundoparcial.model.Capitulo;
import com.example.segundoparcial.repository.CapituloRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CapituloService {

    @Autowired
    private CapituloRepository capituloRepository;

    public List<Capitulo> getAllCapitulos() {
        return capituloRepository.findAll();
    }

    public Optional<Capitulo> getCapituloById(Long id) {
        return capituloRepository.findById(id);
    }

    public Capitulo createCapitulo(Capitulo capitulo) {
        return capituloRepository.save(capitulo);
    }
}

