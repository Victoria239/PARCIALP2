package com.example.segundoparcial.repository;
import com.example.segundoparcial.model.Serie;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaRepository;



    public interface SerieRepository extends JpaRepository<Serie, Long> {

    }

