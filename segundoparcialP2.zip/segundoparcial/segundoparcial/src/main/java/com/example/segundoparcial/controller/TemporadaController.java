package com.example.segundoparcial.controller;

import com.example.segundoparcial.model.Temporada;
import com.example.segundoparcial.service.TemporadaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/temporadas")
public class TemporadaController {

    @Autowired
    private TemporadaService temporadaService;

    @GetMapping
    public List<Temporada> getTemporadas() {
        return temporadaService.getAllTemporadas();
    }

    @GetMapping("/{id}")
    public Optional<Temporada> getTemporada(@PathVariable Long id) {
        return temporadaService.getTemporadaById(id);
    }

    @PostMapping
    public Temporada createTemporada(@RequestBody Temporada temporada) {
        return temporadaService.createTemporada(temporada);
    }
}

