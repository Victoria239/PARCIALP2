package com.example.segundoparcial.controller;
import com.example.segundoparcial.model.Capitulo;
import com.example.segundoparcial.service.CapituloService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/capitulos")
public class CapituloController {

    @Autowired
    private CapituloService capituloService;

    @GetMapping
    public List<Capitulo> getCapitulos() {
        return capituloService.getAllCapitulos();
    }

    @GetMapping("/{id}")
    public Optional<Capitulo> getCapitulo(@PathVariable Long id) {
        return capituloService.getCapituloById(id);
    }

    @PostMapping
    public Capitulo createCapitulo(@RequestBody Capitulo capitulo) {
        return capituloService.createCapitulo(capitulo);
    }
}
