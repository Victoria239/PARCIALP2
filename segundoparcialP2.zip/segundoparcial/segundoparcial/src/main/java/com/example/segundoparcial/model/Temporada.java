package com.example.segundoparcial.model;


import jakarta.persistence.*;
import java.util.List;

    @Entity
    public class Temporada {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        private int numero;
        private int anioLanzamiento;

        @ManyToOne
        @JoinColumn(name = "serie_id")
        private Serie serie;

        @OneToMany(mappedBy = "temporada", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
        private List<Capitulo> capitulos;

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public int getNumero() {
            return numero;
        }

        public void setNumero(int numero) {
            this.numero = numero;
        }

        public int getAnioLanzamiento() {
            return anioLanzamiento;
        }

        public void setAnioLanzamiento(int anioLanzamiento) {
            this.anioLanzamiento = anioLanzamiento;
        }

        public Serie getSerie() {
            return serie;
        }

        public void setSerie(Serie serie) {
            this.serie = serie;
        }

        public List<Capitulo> getCapitulos() {
            return capitulos;
        }

        public void setCapitulos(List<Capitulo> capitulos) {
            this.capitulos = capitulos;
        }

        public void setanioLanzamiento(int i) {

        }
    }


