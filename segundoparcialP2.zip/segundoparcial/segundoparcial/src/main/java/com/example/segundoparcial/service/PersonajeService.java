package com.example.segundoparcial.service;

import com.example.segundoparcial.model.Personaje;
import com.example.segundoparcial.repository.PersonajeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PersonajeService {

    @Autowired
    private PersonajeRepository personajeRepository;

    public List<Personaje> getAllPersonajes() {
        return personajeRepository.findAll();
    }

    public Optional<Personaje> getPersonajeById(Long id) {
        return personajeRepository.findById(id);
    }

    public Personaje createPersonaje(Personaje personaje) {
        return personajeRepository.save(personaje);
    }
}
