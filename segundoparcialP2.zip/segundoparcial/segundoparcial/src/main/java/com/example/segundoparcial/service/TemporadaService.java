package com.example.segundoparcial.service;


import com.example.segundoparcial.model.Temporada;
import com.example.segundoparcial.repository.TemporadaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TemporadaService {

    @Autowired
    private TemporadaRepository temporadaRepository;

    public List<Temporada> getAllTemporadas() {
        return temporadaRepository.findAll();
    }

    public Optional<Temporada> getTemporadaById(Long id) {
        return temporadaRepository.findById(id);
    }

    public Temporada createTemporada(Temporada temporada) {
        return temporadaRepository.save(temporada);
    }
}
