package com.example.segundoparcial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SegundoparcialApplication {

	public static void main(String[] args) {
		SpringApplication.run(SegundoparcialApplication.class, args);
	}

}
