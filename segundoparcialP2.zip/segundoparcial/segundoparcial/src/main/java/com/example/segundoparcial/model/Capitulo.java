package com.example.segundoparcial.model;

import jakarta.persistence.*;

    @Entity
    public class Capitulo {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        private int numero;
        private String nombre;
        private String descripcion;
        private String imagen1;
        private String imagen2;
        private double calificacion;
        private String Codigo;

        @ManyToOne
        @JoinColumn(name = "temporada_id")
        private Temporada temporada;

        public Capitulo() {

        }

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public int getNumero() {
            return numero;
        }

        public void setNumero(int numero) {
            this.numero = numero;
        }

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public String getDescripcion() {
            return descripcion;
        }

        public void setDescripcion(String descripcion) {
            this.descripcion = descripcion;
        }

        public String getImagen1() {
            return imagen1;
        }

        public void setImagen1(String imagen1) {
            this.imagen1 = imagen1;
        }

        public String getImagen2() {
            return imagen2;
        }

        public void setImagen2(String imagen2) {
            this.imagen2 = imagen2;
        }

        public double getCalificacion() {
            return calificacion;
        }

        public void setCalificacion(double calificacion) {
            this.calificacion = calificacion;
        }

        public Temporada getTemporada() {
            return temporada;
        }

        public void setTemporada(Temporada temporada) {
            this.temporada = temporada;
        }

        public String getCodigo() {
            return Codigo;
        }

        public void setCodigo(String codigo) {
            Codigo = codigo;
        }

        public Capitulo(Long id, int numero, String nombre, String descripcion, String imagen1, String imagen2, double calificacion, String codigo, Temporada temporada) {
            this.id = id;
            this.numero = numero;
            this.nombre = nombre;
            this.descripcion = descripcion;
            this.imagen1 = imagen1;
            this.imagen2 = imagen2;
            this.calificacion = calificacion;
            Codigo = codigo;
            this.temporada = temporada;
        }

        }

    


