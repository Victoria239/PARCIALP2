package com.example.segundoparcial.controller;


import com.example.segundoparcial.model.Personaje;
import com.example.segundoparcial.service.PersonajeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/personajes")
public class PersonajeController {

    @Autowired
    private PersonajeService personajeService;

    @GetMapping
    public List<Personaje> getPersonajes() {
        return personajeService.getAllPersonajes();
    }

    @GetMapping("/{id}")
    public Optional<Personaje> getPersonaje(@PathVariable Long id) {
        return personajeService.getPersonajeById(id);
    }

    @PostMapping
    public Personaje createPersonaje(@RequestBody Personaje personaje) {
        return personajeService.createPersonaje(personaje);
    }
}

